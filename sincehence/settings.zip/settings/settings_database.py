import os
import ast
# from dotenv import load_dotenv
from . import BASE_DIR, DEBUG
# load_dotenv(os.path.join(BASE_DIR, '.env.sincehence'))
# DEBUG = ast.literal_eval(os.getenv('DEBUG', 'False'))

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'sincehencenew' if DEBUG else "sincehen_one",
        'USER': 'root' if DEBUG else "sincehen_one",
        'PASSWORD': '' if DEBUG else "sTh2a6pS3xRq",
        'HOST':'localhost',
        'PORT': '3306',
        'OPTIONS': {
        'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        }
    }
}


    
    


