import os
# from dotenv import load_dotenv
# from . import BASE_DIR
# load_dotenv(os.path.join(BASE_DIR, '.env.sincehence'))
DEFAULT_FROM_EMAIL = "no-reply@sincehence.co.uk"
EMAIL_HOST = "mail.sincehence.co.uk"
EMAIL_PORT= "465"
EMAIL_HOST_USER = "no-reply@sincehence.co.uk"
EMAIL_HOST_PASSWORD = "daa6pDg5BwGdX2LHAT9N9x"
EMAIL_USE_TLS=False
EMAIL_USE_SSL=True

