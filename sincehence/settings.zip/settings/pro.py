import os
# from dotenv import load_dotenv
from . import BASE_DIR
# load_dotenv(os.path.join(BASE_DIR, '.env.sincehence'))


EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'


from .settings_email import *

from .settings_logs import *

from .settings_security import *

from .settings_summernote import *

CACHES = {    
    'default': {
        'BACKEND': 'django.core.cache.backends.filebased.FileBasedCache',
        'LOCATION': os.path.join(BASE_DIR, 'cache'),
        'TIMEOUT': 3600,
        'OPTIONS': {
            'MAX_ENTRIES': 1000
        }
    }
}

CACHE_MIDDLEWARE_SECONDS = 3600

RECAPTCHA_PUBLIC_KEY = "6LcvqAcfAAAAACiP-NqIHp3p6u74as-qZkXWsMcO"
RECAPTCHA_PRIVATE_KEY = "6LcvqAcfAAAAAB-8E1DpN17WTGYPljsBCIa0fig_"
# RECAPTCHA_DOMAIN = 'www.recaptcha.net'
SILENCED_SYSTEM_CHECKS = ['captcha.recaptcha_test_key_error']